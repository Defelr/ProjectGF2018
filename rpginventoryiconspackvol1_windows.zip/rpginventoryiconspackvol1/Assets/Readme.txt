--------------------------------------------------------------
              ICON EDITING TIP #1
--------------------------------------------------------------
You can find all the icons in PSD files as well which you can
use to produce more variants of them. All the files are layered
so you can easily change parts by your need.

Recoloring is the most simple way to get many different icons
out of the single one.




--------------------------------------------------------------
              ICON EDITING TIP #2
--------------------------------------------------------------
If you want a good, sharp quality of the icons, use 'Sharpen' 
effect in photoshop after resizing the icon.

Example:

- You open one of the PSD Icons of 128x128px size
- Do the work
- Flatten Image
- Resize to 64x64px
- Use 'Sharpen' filter



_________________________________________________________
  ~ Game assets by game developer for game developers ~

           ---- www.emberheartgames.com ----
          ---- www.courierofthecrypts.com ----
__________________________________________________________